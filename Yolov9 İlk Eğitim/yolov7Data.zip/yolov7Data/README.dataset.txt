# KECELAKAAN > 2023-03-13 6:58pm
https://universe.roboflow.com/institute-technology-of-bandung/kecelakaan

Provided by a Roboflow user
License: Public Domain

