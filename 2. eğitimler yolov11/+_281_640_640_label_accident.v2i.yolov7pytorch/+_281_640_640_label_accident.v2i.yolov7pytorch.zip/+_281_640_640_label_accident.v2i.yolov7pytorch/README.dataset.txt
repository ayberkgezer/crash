# accident > 2023-11-02 1:52pm
https://universe.roboflow.com/nuv-0jcvz/accident-swwup

Provided by a Roboflow user
License: CC BY 4.0

