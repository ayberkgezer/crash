# broken Vehicles+ > 2023-04-18 7:17am
https://universe.roboflow.com/team-ks/broken-vehicles

Provided by a Roboflow user
License: CC BY 4.0

