# cars > 2023-11-27 1:17pm
https://universe.roboflow.com/jood-alharbi-tonig/cars-qqko8

Provided by a Roboflow user
License: CC BY 4.0

