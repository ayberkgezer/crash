# Car Accident Detector2 > 2023-04-15 10:54pm
https://universe.roboflow.com/bakhyt-re5p9/car-accident-detector2

Provided by a Roboflow user
License: CC BY 4.0

