# ceo > 2023-04-23 1:04am
https://universe.roboflow.com/bakhyt-re5p9/ceo-buqlm

Provided by a Roboflow user
License: CC BY 4.0

