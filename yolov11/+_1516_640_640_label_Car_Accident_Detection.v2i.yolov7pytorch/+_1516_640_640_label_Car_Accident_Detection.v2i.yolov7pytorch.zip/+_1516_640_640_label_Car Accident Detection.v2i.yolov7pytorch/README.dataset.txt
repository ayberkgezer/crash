# Car Accident Detection > 2023-11-05 1:37pm
https://universe.roboflow.com/car-accident-detection-2uoh6/car-accident-detection-7zjkk

Provided by a Roboflow user
License: Public Domain

