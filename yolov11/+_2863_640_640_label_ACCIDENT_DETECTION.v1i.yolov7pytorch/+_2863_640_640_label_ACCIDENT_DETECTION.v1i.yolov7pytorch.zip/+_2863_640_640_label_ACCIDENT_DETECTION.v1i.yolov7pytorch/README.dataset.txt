# ACCIDENT_DETECTION > 2023-04-28 6:31pm
https://universe.roboflow.com/hh-ou0i3/accident_detection-3qcmk

Provided by a Roboflow user
License: CC BY 4.0

